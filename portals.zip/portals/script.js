function showLogin(type) {
    
    document.getElementById('student-login').style.display = 'none';
    document.getElementById('faculty-login').style.display = 'none';
    document.getElementById('stock-login').style.display = 'none';
    document.getElementById('success-message').style.display = 'none';

    // Show the selected login form
    if (type === 'student') {
        document.getElementById('student-login').style.display = 'block';
    } else if (type === 'faculty') {
        document.getElementById('faculty-login').style.display = 'block';
    } else if (type === 'stock') {
        document.getElementById('stock-login').style.display = 'block';
    }
}

function showSuccess() {
    
    document.getElementById('student-login').style.display = 'none';
    document.getElementById('faculty-login').style.display = 'none';
    document.getElementById('stock-login').style.display = 'none';


    document.getElementById('success-message').style.display = 'block';

    
    return false;
}
