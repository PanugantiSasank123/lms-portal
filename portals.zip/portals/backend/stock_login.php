<?php
include 'db_connect.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['stock_email'];
    $password = password_hash($_POST['stock_password'], PASSWORD_DEFAULT); // Hash the password

    // Insert data into the users table
    $sql = "INSERT INTO users (user_type, email, password) 
            VALUES ('stock', '$email', '$password') 
            ON DUPLICATE KEY UPDATE password='$password'";

    if ($conn->query($sql) === TRUE) {
        echo "Stock login successful!";
    } else {
        echo "Error: " . $conn->error;
    }
}

$conn->close();
?>
