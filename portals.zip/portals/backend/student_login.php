<?php
include 'db_connect.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['student_email'];
    $password = $_POST['student_password'];
    
    // Check if the user exists
    $sql = "SELECT password FROM users WHERE email = '$email' AND user_type = 'student'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User exists, verify password
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            echo "Login successful!"; 
        } else {
            echo "Invalid password."; 
        }
    } else {
        
        $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash the password

        
        $sql = "INSERT INTO users (user_type, email, password) 
                VALUES ('student', '$email', '$hashed_password')";

        if ($conn->query($sql) === TRUE) {
            echo "Registration successful! You can now log in."; 
        } else {
            echo "Error: " . $conn->error; 
        }
    }
}

$conn->close();
?>
